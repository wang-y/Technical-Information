package org.wanghui.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class AuthInterceptor implements InvocationHandler{

	Payment payment;
	
	public AuthInterceptor(Payment payment){
		this.payment = payment;
	}
	
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		//System.out.println(proxy);
		checkUser();
		return  method.invoke(payment, args);
		
	}
	
	public void checkUser(){
		System.out.println("检查用户是否有资格支付。");
	}

}
