package org.wanghui.proxy.gen;

public class RealProxy implements Real{
	private RealSub sub;
	
	public void setSub(RealSub sub){
		this.sub = sub;
	}
	public void request(){
		System.out.println("before");
		sub.request();
		System.out.println("after");
		
	}
}
