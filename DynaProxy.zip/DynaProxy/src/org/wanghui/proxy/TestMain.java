package org.wanghui.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

public class TestMain {
	public static void main(String[] args){
		Payment ment = new PaymentImpl();
		InvocationHandler handler = new AuthInterceptor(ment);
		Payment pay1 = (Payment)Proxy.newProxyInstance(PaymentImpl.class.getClassLoader(),
				PaymentImpl.class.getInterfaces(),
				handler);
		pay1.pay();
		

		
	}
}
