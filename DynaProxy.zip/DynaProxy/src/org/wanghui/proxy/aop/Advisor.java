package org.wanghui.proxy.aop;

import java.lang.reflect.Method;

public interface Advisor {
	
	    public void doInAdvisor(Object proxy, Method method, Object[] args);
}