package org.wanghui.proxy.aop;

import java.lang.reflect.Method;

public class BeforeMethodAdvisor implements Advisor {

	public void doInAdvisor(Object proxy, Method method, Object[] args) {
		System.out.println("检查用户是否有资格支付 ");
	}
}