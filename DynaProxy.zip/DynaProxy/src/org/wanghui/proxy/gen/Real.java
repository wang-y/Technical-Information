package org.wanghui.proxy.gen;

public interface Real {
	public void request();
}
