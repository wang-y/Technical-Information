package org.wanghui.proxy;

public class PaymentImpl implements Payment{

	@Override
	public void pay() {
		System.out.println("给钱");
	}

}
