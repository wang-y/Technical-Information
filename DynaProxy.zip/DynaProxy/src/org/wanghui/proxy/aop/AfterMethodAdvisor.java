package org.wanghui.proxy.aop;

import java.lang.reflect.Method;

public class AfterMethodAdvisor implements Advisor {
	/**
	 * 在方法执行后所进行的操作.
	 */
	public void doInAdvisor(Object proxy, Method method, Object[] args) {
		System.out.println("用户的账号冻结");
	}
}