package org.wanghui.proxy.aop;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class AopHandler implements InvocationHandler {
	// 需要代理的目标对象
	private Object target;
	// 方法前置顾问
	Advisor beforeAdvisor;
	// 方法后置顾问
	Advisor afterAdvisor;


	public Object setObject(Object target) {
		// 设置代理目标对象
		this.target = target;
		// 根据代理目标对象生成动态代理对象
		Object obj = Proxy.newProxyInstance(target.getClass().getClassLoader(),
				target.getClass().getInterfaces(), this);
		return obj;
	}


	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		// 进行业务方法的前置处理
		if (beforeAdvisor != null) {
			beforeAdvisor.doInAdvisor(proxy, method, args);
		}
		// 执行业务方法
		Object result = method.invoke(target, args);
		// 进行业务方法的后置处理
		if (afterAdvisor != null) {
			afterAdvisor.doInAdvisor(proxy, method, args);
		}
		// 返回结果对象
		return result;
	}

	public void setBeforeAdvisor(Advisor advisor) {
		this.beforeAdvisor = advisor;
	}

	public void setAfterAdvisor(Advisor advisor) {
		this.afterAdvisor = advisor;
	}
}