package org.wanghui.proxy.gen;

public class RealSub implements Real{
	public void request(){
		System.out.println("111111111");
	}
}
