package org.wanghui.proxy;

public interface Payment {
	public void pay();
}
