package org.wanghui.proxy.ioc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;


public class User {
	private String name;
	private String pwd;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public static boolean valiperiod(String cm) throws Exception {
		// TODO Auto-generated method stub
		char[] period = cm.toCharArray();
		Integer periodLen = period.length;
		Set<Character> temp = new HashSet<Character>();
		for(Character c : period) {
			if(!Character.isDigit(c)) {
				return false;
			}
			if(!StringUtils.equals(c.toString(), "1") && !StringUtils.equals(c.toString(), "2")&& !StringUtils.equals(c.toString(), "3")&& !StringUtils.equals(c.toString(), "4")&&!StringUtils.equals(c.toString(), "5")&& !StringUtils.equals(c.toString(), "6")&& !StringUtils.equals(c.toString(), "7")) {
				return false;
			}
			temp.add(c);
		}
		if(periodLen !=temp.size()) {
			return false;
		}
		
		return true;
	}
	public static void main(String[] args) throws Exception {
		
		System.out.println(valiperiod("123743"));
		String myString = "2008-09-08";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d = sdf.parse(myString);

		boolean flag = d.before(new Date());
		if(flag)
		System.out.print("早于今天");
		else
		System.out.print("晚于今天");
	}
	
}
