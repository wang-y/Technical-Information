package org.wanghui.proxy.gen;

public class Test {
	
	public static void main(String[] args){
		RealProxy rp = new RealProxy();
		rp.setSub(new RealSub());
		rp.request();
	}
	
}
